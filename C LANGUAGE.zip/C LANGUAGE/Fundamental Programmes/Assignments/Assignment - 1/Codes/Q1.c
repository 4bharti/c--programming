#include <stdio.h>
void main(){
    // hour wages = a (We are assuming hourly wages as 10)
    // working hours = b
    // extra working hours = c
    // extra wages = d
    // weekly wages = e 
    int a=10,b,c,d,e;
    printf("Enter The Number Of Working Hours=");
    scanf("%d",&b);
    if(b>30){
        c=b-30;
        d=a*c*2;
        e=30*a*d;
        printf("Weekly wages of the employee=%d",e);
    }
    else{
        e=a*b;
        printf("Weekly wages of the employee=%d",e);
    }
}