#include <stdio.h>
void main(){
    printf("\t\t\tFREQUENCY OF WAVE\n");
    float f,lambda,c;
    printf("Enter the wavelength of wave=");
    scanf("%f",&lambda);
    printf("Enter the speed of wave=");
    scanf("%f",&c);
    f=c/lambda;
    printf("Frequence of Wave = %0.1f",f);
}