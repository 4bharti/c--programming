#include <stdio.h>
int main(){
    		if (sizeof(int) > -1){
        		printf("Yes");
		}
    		else{
        		printf("No");
		}
    		return 0;
}
