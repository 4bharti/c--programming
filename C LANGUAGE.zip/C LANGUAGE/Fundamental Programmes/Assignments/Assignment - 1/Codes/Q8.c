#include<stdio.h>
void main()
{
   char x, a='c';
   x=printf("%c",a);
   printf("%d",x);
}
