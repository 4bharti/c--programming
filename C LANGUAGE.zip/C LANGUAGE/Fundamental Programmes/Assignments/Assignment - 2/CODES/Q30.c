#include <stdio.h>
void main(){
    int Satyam=50,suman=70,shyam=80,user_input,user_input2,user_input3;
    float Average;
    printf("\t\t\t\t **** WELCOME TO THE RESULT SECTION **** \n");
    printf("Do you want to see the resut of the students?\n");
    printf("press 1 for yes = ");
    scanf("%d",&user_input);
    if(user_input==1){
        printf("Satyam = 50 \n");
        printf("Suman = 70 \n");
        printf("Shyam = 80 \n");
        printf("\n");
        printf("Have You Seen? \n");        
        printf("press 2 for yes = ");
        scanf("%d",&user_input2);
        if(user_input2==2){
            printf("Do you want to Calculate the average mark of the students?\n");
            printf("press 3 for yes = ");
            scanf("%d",&user_input3);
            if(user_input3==3){
                Average=(Satyam+suman+shyam)/3;
                printf("Average Marks Of Students = %.2f \n",Average);
                printf("\n");
                printf("Thanks For Using The result Section, You May Now Leave");
            }  
            else{
                printf("Okay, Thanks for Visiting");
            }
        }
        else{
            printf("Okay");
        }
    }
    else{
        printf("Okay Bye");
    }
}