#include <stdio.h>
void main(){
    // Mohan Gave saurav = 50 Rs. and,
    // Sejal = 80 rs.
    // But he wants to give saurav = 80 Rs. and,
    // Sejal = 50 rs.
    // Saurav = a , Sejal = b , Mohan = c
    int a,b,c;
    printf("Mohan Gave rupess to Saurav = ");
    scanf("%d",&a);
    printf("Mohan Gave rupess to Sejal = ");
    scanf("%d",&b);
    printf("\t\t\t **** Mohan Wants To Swap The Rupees Between Saurav And Sejal ***\n");
    c=a;
    a=b;
    b=c;
    printf("Rupess Saurav Have After Swapping = %d \n",a);
    printf("Rupess Sejal Have After Swapping = %d \n",b);
}