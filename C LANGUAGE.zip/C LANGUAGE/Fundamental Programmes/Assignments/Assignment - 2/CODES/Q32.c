#include <stdio.h>
void main(){
    int t=3,T;
    float s=4,S,D;
    printf("Speed is = %f km/h \n",s);
    S=s*5/18;
    printf("Speed in m/s  = %f m/s \n",S);
    printf("Time is = %d minute \n",t);
    T=t*60;
    printf("Time in Seconds = %d Seconds\n",T);
    D=S*T;
    printf("Distance Travelled=%f",D);
}