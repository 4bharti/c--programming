#include <stdio.h>
void main(){
    printf("My Name is = Tanishq Soni\n");
    printf("DOB = 17/11/2003\n");
    printf("Mobile Number = 8445933567\n");
}