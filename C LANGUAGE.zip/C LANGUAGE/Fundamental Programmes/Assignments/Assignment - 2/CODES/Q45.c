#include<stdio.h>
int main()
{
 int b,c=25;
 printf("%d",b);
}
