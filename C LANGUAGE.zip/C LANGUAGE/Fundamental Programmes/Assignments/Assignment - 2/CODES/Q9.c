#include <stdio.h>
void main(){
    long long mobile_number;
    printf("Enter Your Mobile Number=");
    scanf("%lld",&mobile_number);
    printf("%lld",mobile_number);
}