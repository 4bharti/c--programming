#include <stdio.h>
void main(){
    int a,i;
    printf("Enter the range yo need to know the prime numbers");
    scanf("%d",&a);
    for(i=2;i<=a;i++);{
        for (j=2,j<i;j++){
            if(i%j==0);
            printf();
        }
    }
}