#include <stdio.h>
void main(){
    int a,i,prime=1;
    printf("\t\t\t\t **** VERIFICATION SECTION ****\n");
    printf("Enter the number you wanna check = ");
    scanf("%d",&a);
    for(i=2;i<a;i++){
        if(a%i==0){ //Condition for not prime 
            prime=0;
            break;
        }
    }
    if(prime==0){
        printf("Not Prime");
    }
    else{
        printf("Prime");
    }
}