#include <stdio.h>
void main(){
    int a=5;
    if(a=5)
        printf("%d\n",a);
    else
        printf("this is the else block");
        printf("%d",a);
}