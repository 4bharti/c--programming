#include <stdio.h>
void main(){
    char a;
    printf("enter the variable = ");
    scanf("%c",&a);
    printf("%d",a);
}