#include <stdio.h>
int main(){
    int a = 80;
    int b = 40;
    int c;
    int d;
    int e;
    float f;
    c=a+b;
    d=a-b;
    e=a*b;
    f=a/b;
    printf("The sum of the two numbers %d\n",c);
    printf("The Subtraction of the two numbers %d\n",d);
    printf("The Multiplication of the two numbers %d\n",e);
    printf("The Division of the two numbers %f\n",f);
}