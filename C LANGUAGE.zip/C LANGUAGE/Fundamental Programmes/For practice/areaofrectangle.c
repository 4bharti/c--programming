#include <stdio.h>
void main(){
    printf("\t\t\t\tAREA OF RECTANGLE\n");
    int area,l,b;
    printf("Length of Rectangle=");
    scanf("%d",&l);
    printf("breadth of Rectangle=");
    scanf("%d",&b);
    area=l*b;
    printf("area of Rectangle=%d",area);
}