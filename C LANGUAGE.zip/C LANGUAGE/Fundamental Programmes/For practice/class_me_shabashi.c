#include <stdio.h>
void main(){
    int a=10,b=12,c=25;
    if(a>b>c){
        printf("Hello");
    }
    else{
        printf("Bye");
    }
}