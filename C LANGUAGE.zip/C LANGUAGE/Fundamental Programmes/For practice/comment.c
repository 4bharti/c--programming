//SINGLE LINE COMMENT - //for writing the comments we use 2 forward slashes ('//') like this.
//Multi line Comment - Use Like This :
/*Tanishq soni
Anmol soni 
*/