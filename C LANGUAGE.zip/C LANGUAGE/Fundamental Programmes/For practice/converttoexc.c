//In the terminal you just have to type "gcc (file name).c - o (file name.(Jis ext. me convert krwaana chaahte ho))"
//EG:- gcc converttoexc.c - o converttoexc.exc

#include <stdio.h>
int main(){
    printf("HELLO WORLD");
}