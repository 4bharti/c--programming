// Check The Output :-
#include <stdio.h>
void main(){
    int a=10;
    if(a=11){
        printf("I am 11");
    }
    else{
        printf("I am not 11");
    }
}