#include <stdio.h>
void main(){
    int i=95;
    char c=97;
    printf("%d,%d\n",sizeof(i),sizeof(c)); 
}