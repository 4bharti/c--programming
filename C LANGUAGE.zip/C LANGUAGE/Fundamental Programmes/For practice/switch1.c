#include <stdio.h>
void main(){
    int a=5;
    switch (a){
    default:
        printf("Hello");
    case 1:
        printf("Bye");
    case 5:
        printf("bie");
    case 2:
        printf("hie");
    }
}