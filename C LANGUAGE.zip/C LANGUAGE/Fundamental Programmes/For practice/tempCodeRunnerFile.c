else{
            //     printf("not a prime\n");
            // }