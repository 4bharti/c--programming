#include <stdio.h>
void main(){
    int a;
    printf("Enter The Number = ");
    scanf("%d",&a);
    while (a<=20){
        printf("%d \n",a);
        a++;
    }
}