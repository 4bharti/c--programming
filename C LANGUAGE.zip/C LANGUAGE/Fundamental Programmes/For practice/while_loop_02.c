#include <stdio.h>
void main(){
    int i=0;
    while (i<=20){
        if(i>=10){
            printf("The value of i is %d\n",i);
        }
        else if(i<10){
            printf("%d\n",i);
        }
        i++;
    }
}