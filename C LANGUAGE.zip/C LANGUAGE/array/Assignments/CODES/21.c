#include <stdio.h>
void main(){
    int a[9]={48,51,51,68,87,89,45,48,98},i,b,count=0;
    for(i=0;i<9;i++){
        printf("%d ",a[i]);
    }
    printf("\n");
    printf("Enter the element you want to delete = ");
    scanf("%d",&b);
    int update[9-count];
    for(i=0;i<9;i++){
        if(a[i]==b){
            a[i]= 0;
            count++;
        }
    }

    for(i=0;i<9;i++){
        printf("%d ",a[i]);
    }
}