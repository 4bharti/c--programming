#include <stdio.h>
void main(){
    int a[8]={578, 0, 179, 87, 109, 43, 44, 477758},i,j;
    for(int k=0;k<4;k++){
        for(i=0;i<8;i++){
            if(a[i]>a[i+1]){
                j=a[i+1];
                a[i+1]=a[i];
                a[i]=j;
            }
        }
    }
    for(i=0;i<8;i++){
        printf("%d ",a[i]);
    }
}