#include <stdio.h>
void main(){
    int a[7]={19,45,67,78,89,56,78},i,count=0;
    for(i=0;i<=7;i++){
        if(a[i]==78){
            printf("78 is present on %d index\n",i);
            count+=1;
        }
    }
    printf("78 Is present %d times",count);
}