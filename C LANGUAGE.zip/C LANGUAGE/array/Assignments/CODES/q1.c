#include <stdio.h>
void main(){
    int a[100],n,i;
    printf("Enter the number of elements = ");
    scanf("%d",&n);

    for(i=0;i<n;i++){
        scanf("%d",&a[i]);
    }

    printf("the array created is : ");

    for(i=0;i<n;i++){
        printf("%d",a[i]);
    }
    printf("\n");
}