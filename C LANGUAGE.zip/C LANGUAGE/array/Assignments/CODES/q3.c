#include <stdio.h>
void main(){
    int a[100],n,i,avg,sum=0;
    printf("Enter the size = ");
        scanf("%d",&n);

    for(i=0;i<n;i++){
        scanf("%d",&a[i]);
    }
    printf("Elements are = ");
    for(i=0;i<n;i++){
        printf("%d",a[i]);
    }
    for(i=0;i<n;i++){
        sum=sum+a[i];
    }
    printf("Sum is = %d\n",sum);
    for(i=0;i<n;i++){
        avg=sum/n;
    }
    printf("Average is = %d",avg);
}