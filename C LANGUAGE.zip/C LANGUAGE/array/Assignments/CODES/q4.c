#include <stdio.h>
void main(){
    int a[100],n,i,avg,count1=0,count2=0,count3=0;
    printf("Enter the size = ");
        scanf("%d",&n);

    for(i=0;i<n;i++){
        scanf("%d",&a[i]);
    }
    printf("Elements are = ");
    for(i=0;i<n;i++){
        printf("%d",a[i]);
    }
    for(i=0;i<n;i++){
        if(a[i]>0){
            count1++;
        }
        else if(a[i]<0){
            count2++;
        }
        else{
            count3++;
        }
    }
    printf("Positives are = %d\n",count1);
    printf("Negatives are = %d\n",count2);
    printf("Zeroes are = %d\n",count3);
}