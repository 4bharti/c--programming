#include <stdio.h>
#include <math.h>
void main(){
    int a[100],n,i,avg,sum=0;
    float sd=0;
    printf("Enter the size = ");
        scanf("%d",&n);

    for(i=0;i<n;i++){
        scanf("%d",&a[i]);
    }
    printf("Elements are = ");
    for(i=0;i<n;i++){
        printf("%d",a[i]);
    }
    for(i=0;i<n;i++){
        sum=sum+a[i];
    }
    avg=sum/n;
    for(i=0;i<n;i++){
    sd=sd + pow(avg-a[i],2);
    }
    float z;
    z=sqrt(sd)/n;
    printf("\nStandard deviation = %f",z);
}