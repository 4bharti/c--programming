#include <stdio.h>
int main()
{
    int i;
    int a[7] = {12,67,45,34,87,90,23};
    for(i=2; i<=5;i++)
    a[i]=a[i+1];
    for (i = 0; i < 7; i++)
    printf("%d ", a[i]);
    return 0;
}
