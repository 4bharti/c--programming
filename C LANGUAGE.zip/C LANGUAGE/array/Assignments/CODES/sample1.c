#include<stdio.h>
 int main(){
int arr[10] = {1,2,3};
printf("%d %d %d  %d",arr[0],arr[2],arr[4],arr[6]);
return 0;
}
