#include<stdio.h>
int main(){
    int i,j,count=0,n,a[5];
    printf("\t\t\tEnter the value of the array \n");
    for(i=0;i<5;i++){
        printf("Enter the value of the array = ");
        scanf("%d",&a[i]);
    }
    for(i=0;i<5;i++){
        for(j=0;j<5;j++){
            if(a[i]==a[j]){
                count++;
            }
        }
        if(count>1){
                printf("Frequency of %d is %d\n",a[i],count);
        }
        count=0;
    }
}
