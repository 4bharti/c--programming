#include <stdio.h>
int sum(){
    int a,b,result;
    printf("Enter the two values = ");
    scanf("%d %d", &a,&b);
    return a+b;
}
int sub(){
    int a,b,result;
    printf("Enter the two values = ");
    scanf("%d %d", &a,&b);
    return a-b;
}
int product(){
    int a,b,result;
    printf("Enter the two values = ");
    scanf("%d %d", &a,&b);
    return a*b;
}
int div(){
    int a,b,result;
    printf("Enter the two values = ");
    scanf("%d %d", &a,&b);
    return a/b;
}

int main(){
    int a,result,b,c;
    printf("Select one opteration in the Arithmatic calculator :-\n");
    printf("1. Addition \t 2. Subtraction \t 3. Multiplication \t 4. Division \n");
    printf("--->\t");
    scanf("%d",&a);
    if(a!=1 && a!=2 && a!=3 && a!=4){
        printf("No Opertions found,Please Select from above Options");
    }

    else if(a==1){
        result = sum();
        printf("Sum is = %d", result);
    }
    
    else if(a==2){
        result = sub();
        printf("Subtracton is = %d",result);
    }

    else if(a==3){
        result = product();
        printf("product is = %d",result);
    }

    else if(a==4){
        result = div();
        printf("Division is = %d",result);
    }

    else{
        printf("Thanks for using our application");
    }

    return 0;
}