#include <stdio.h>

int change(int a){
    a=77;
    return a;
}

void main(){
    int b = 12;
    change(b);
    printf("The vakue of b is = %d ",b);
}