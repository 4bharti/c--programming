#include <stdio.h>

int factorial(int a);

void main(){
    int a;
    printf("Enter the number for factorial = ");
    scanf("%d",&a);
    printf("Factorial is = %d",factorial(a));

}
int factorial(int a){
    if(a==1 || a==0){
        return 1;
    }
    else{
        return a*factorial(a-1);
    }
}
