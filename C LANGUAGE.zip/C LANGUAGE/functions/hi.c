#include <stdio.h>
#include <string.h>

void main(){
    char *ptr;
    printf("%d %d",sizeof(*ptr),sizeof(ptr));
}