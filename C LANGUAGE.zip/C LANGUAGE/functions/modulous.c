#include <stdio.h>

int modulous(int a,int b){
    int difference;
    difference=a-b;

    //modulous condition :

    if(difference<0){ 
        difference = -difference;
        return difference;
    }   
    else{
        return difference;
    }
}

void main(){
    int a,b;
    scanf("%d %d",&a,&b);
    printf("%d", modulous(a,b));
}