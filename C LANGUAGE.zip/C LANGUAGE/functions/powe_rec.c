#include <stdio.h>
#include <string.h>
int power(int a,int b);

void main(){
    int a,b;
    scanf("%d",&a);
    scanf("%d",b);
    printf("%d",power(a,b));
}

int power(int a,int b){
    int ans=b,answer;
    if(ans!=0){
        ans--;
        answer=a*power(a,b);
    }
    return answer;
}


char str[]=''