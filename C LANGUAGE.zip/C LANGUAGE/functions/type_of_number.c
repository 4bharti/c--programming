#include <stdio.h>
#include <math.h>

void prime(int a);

void armstrong(int a,int exp);

void perfect(int a,int exp,int exp2);

void main(){
    int a;
    scanf("%d",&a);
    prime(a);
}

void prime(int a){
    int i,flag=1,exp=1;
    for(i=2;i<=sqrt(a);i++){
        if( a%i==0){
            flag = 1;
            break;
        }
        else{
            flag = 0;
        }
    }
    if(flag==0){
        printf("Prime\n");
        exp=0;
        armstrong(a,exp);
    }
    else{
        armstrong(a,exp);
    }
}

void armstrong(int a,int exp){
    int i,count=0,b,sum=0,c,rem,exp2=1;
    b=c=a;
    while(b>0){
        b/=10;
        count++;
    }
    while(c>0){
        sum = sum + pow(c%10,count);
        c/=10;
    }
    if(sum==a){
        printf("Armstrong\n");
        exp2=0;
        perfect(a,exp,exp2);
    }
    else{
        perfect(a,exp,exp2);
    }
}

void perfect(int a,int exp,int exp2){
    int i,sum=0;
    for(i=1;i<a;i++){
        if(a%i==0){
            sum=sum+i;
        }
    }
    if(sum==a){
        printf("Perfect Number");
    }
    else if(exp==1 && exp2 ==1){
        printf("It is neither a prime,neither armstrong nor perfect");
    }
}