#include <stdio.h>
void main(){
    int i;
    char j;
    for(i=1;i<=3;i++){
        for(j=65;j<=68;j++){
            printf("%c",j);
        }
        printf("\n");
    }
}