#include <stdio.h>
void main(){
    int a,b,i,j;
    printf("enter the number of rows = ");
    scanf("%d",&a);
    printf("enter the number of column = ");
    scanf("%d",&b);
    for(i=1;i<=a;i++){
        for(j=1;j<=b;j++){
            if(i==1 || j==1 || i==a || j==b || j==i){
                printf("* ");
            }
            else{
                printf("  ");
            }
        }
        printf("\n");
    }
} 