#include <stdio.h>
void main(){
    int a,b,i,j;
    printf("enter the number of rows = ");
    scanf("%d",&a);
    for(i=1;i<=a;i++){
        for(j=1;j<=i;j++){
            if(i==a || j==i || j==1){
                printf("* ");
            }
            else{
                printf("  ");
            }
        }
        printf("\n");
    }
}