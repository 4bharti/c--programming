#include<stdio.h>
void main()
{
    int i,j,r,c,k;
    printf("enter rows");
    scanf("%d",&r);
    for(i=r; i>=1; i--)
    {
        for(j=1; j<=i; j++)
        {
            printf("*");
        }
        printf("\n");
    }
}