#include <stdio.h>
void main(){
    int a,b,i,j,k;
    printf("enter the number of rows = ");
    scanf("%d",&a);
    printf("enter the number of column = ");
    scanf("%d",&b);
    k=b+1;
    for(i=1;i<=a;i++){
        for(j=1;j<=b;j++){
            if(j>=k-i){
                printf("* ");
            }
            else{
                printf("  ");
            }
        }
        printf("\n");
    }
}