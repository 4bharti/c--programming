#include <stdio.h>
void main(){
    int i,j,r,c;
    printf("Enter the number or rows = ");
    scanf("%d",&r);
    printf("Enter the number or columns = ");
    scanf("%d",&c);
    for(i=1;i<=c;i++){
        for(j=1;j<=r;j++){
            printf("* ");
        }
        printf("\n");
    }
}