#include <stdio.h>
void main(){
    int n,row,column;
    printf("Enter the number of lines = ");
    scanf("%d",&n);
    for(row=1;row<=n;row++){
        for(column=1;column<=row;column++){
            printf("* ");
        }
        printf("\n");
    }
    for(row=n;row>=1;row--){
        for(column=1;column<=row;column++){
            printf("* ");
        }
        printf("\n");
    }
    
}