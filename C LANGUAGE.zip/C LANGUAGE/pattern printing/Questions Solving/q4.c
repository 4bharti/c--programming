#include <stdio.h>
void main(){
    int n,i,b;
    char j;
    printf("enter rows = ");
    scanf("%d",&n);
    b=b+65;
    for(i=1;i<=n;i++){
        for(j=65;j<=b;j++){
            printf("%c",j);
        }
        printf("\n");
    }
}