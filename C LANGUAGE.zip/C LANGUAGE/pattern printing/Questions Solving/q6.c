#include <stdio.h>
void main(){
    int n,i,j,c;
    printf("enter the number of rows = ");
    scanf("%d",&n);
    printf("enter the number of columns = ");
    scanf("%d",&c);
    for(i=1;i<=n;i++){
        for(j=1;j<=c;j++){
            if(j==i||j==1||i==n||j==c||i==1){
                printf("* ");
            }
            else{
                printf("  ");
            }
        }
        printf("\n");
    }
}