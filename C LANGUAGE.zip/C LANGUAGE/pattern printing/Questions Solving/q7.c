#include <stdio.h>
void main(){
    int n,i,j,c;
    printf("enter the number of rows = ");
    scanf("%d",&n);
    printf("enter the number of columns = ");
    scanf("%d",&c);
    for(i=1;i<=n;i++){
        for(j=1;j<=c;j++){
            printf("* ");
        }
        printf("\n");
    }
}